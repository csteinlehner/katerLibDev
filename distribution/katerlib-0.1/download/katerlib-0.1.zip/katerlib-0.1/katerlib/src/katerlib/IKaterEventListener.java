package katerlib;


public interface IKaterEventListener {
	public void onActionStateChange(IKaterEventDispatcher dispatcher, EKaterEventState theState);
}
