package katerlib;

public enum EKaterEventState {finished, started}